package com.menuservice.java.service;

import com.menuservice.java.dto.FoodResponseDto;

public interface MenuService {

	public FoodResponseDto getFoodItemByName(String foodName);

}

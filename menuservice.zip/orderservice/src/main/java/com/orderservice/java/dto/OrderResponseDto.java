package com.orderservice.java.dto;

import java.util.List;

public class OrderResponseDto {
	private Integer orderId;
	private Double totalCost;
	private long orderTime;

	private List<Orders> items;

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public long getOrderTime() {
		return orderTime;
	}

	public void setOrderTime(long orderTime) {
		this.orderTime = orderTime;
	}

	public Double getTotalCost() {
		return totalCost;
	}

	public void setTotalCost(Double totalCost) {
		this.totalCost = totalCost;
	}

	public List<Orders> getItems() {
		return items;
	}

	public void setItems(List<Orders> items) {
		this.items = items;
	}
}

package com.orderservice.java.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.orderservice.java.dto.OrderRequestDto;
import com.orderservice.java.dto.Orders;
import com.orderservice.java.entity.OrderDetails;
import com.orderservice.java.repo.OrderRepo;
import com.orderservice.java.service.OrderService;

public class OrderServiceImpl implements OrderService {

}

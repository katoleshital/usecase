package com.orderservice.java.dto;

import java.util.List;

public class OrderRequestDto {

	private Integer userId;

	private List<Orders> items;

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public List<Orders> getItems() {
		return items;
	}

	public void setItems(List<Orders> items) {
		this.items = items;
	}

}

package com.orderservice.java.service;

import com.orderservice.java.dto.FoodResponseDto;
import com.orderservice.java.dto.OrderRequestDto;

public interface OrderService {

	//void saveOrderDetails(OrderRequestDto orderRequestDto);

	// void saveOrderDetails(OrderRequestDto orderRequestDto);
	//public FoodResponseDto getFoodItemByName(String foodName);

}

package com.orderservice.java.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.orderservice.java.entity.Menu;
import com.orderservice.java.entity.OrderDetails;

@Repository
public interface OrderRepo extends JpaRepository<OrderDetails, Integer> {

}

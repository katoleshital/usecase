package com.account.java.dto;

import java.time.LocalDateTime;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;


public class OrderDetailResponseDTO {

	private Integer orderDetailId;
	private int quantity;
	private float totalPrice;
	private LocalDateTime date;
	private long oderNumber;
	
	
	public Integer getOrderDetailId() {
		return orderDetailId;
	}
	public void setOrderDetailId(Integer orderDetailId) {
		this.orderDetailId = orderDetailId;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public float getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(float totalPrice) {
		this.totalPrice = totalPrice;
	}
	public LocalDateTime getDate() {
		return date;
	}
	public void setDate(LocalDateTime date) {
		this.date = date;
	}
	public long getOderNumber() {
		return oderNumber;
	}
	public void setOderNumber(long oderNumber) {
		this.oderNumber = oderNumber;
	}
	

}

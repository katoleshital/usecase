package com.account.java.service;

import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.account.java.dto.OrderDetailRequestDTO;
import com.account.java.entity.Transaction;
import com.account.java.entity.Wallet;
import com.account.java.exception.InsufficientBalanceException;
import com.account.java.exception.UserNotFoundException;
import com.account.java.repository.AccountRepository;
import com.account.java.repository.TransactionRepository;

@Service
public class AccountServiceImpl implements AccountService {

	@Autowired
	AccountRepository accountRepository;
	@Autowired
	TransactionRepository transactionRepository;
	Optional<Wallet> wallet;
	@Override
 	public float getbalance(Integer userId) {
		wallet=accountRepository.findByUserId(userId);  
       if(wallet!=null) {
		return wallet.get().getBalance();
       }
       else {
    	    throw new UserNotFoundException("User Not Found");
       }
	}

	@Override
	public String transaction(OrderDetailRequestDTO dto) {
		if(getbalance(dto.getUserId())>=dto.getTotalPrice()) {
			Transaction transaction=new Transaction();
			transaction.setAmount(getbalance(dto.getUserId())-dto.getTotalPrice());
			transaction.setDate(LocalDateTime.now());
			transaction.setStatus("Success");
		    transactionRepository.save(transaction);
		    
		     Wallet w=new Wallet();
		     w.setWalletId(wallet.get().getWalletId());
		     w.setUserId(wallet.get().getUserId());
		     w.setBalance(getbalance(dto.getUserId())-dto.getTotalPrice());
		    
		    accountRepository.save(w);
		    return "Transaction Succesfull";
		}
		else {
			 throw new InsufficientBalanceException("No Sufficient Balance");
		}
		
	}

}

package com.account.java.dto;

import lombok.Data;

@Data
public class OrderDetailRequestDTO {
	
	private float totalPrice;
	private Integer userId;

	
}

package com.account.java.feign;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.account.java.dto.OrderDetailResponseDTO;



@FeignClient("ORDERSERVICE")
public interface OrderServiceClient {

	@GetMapping("/OrderHistory")
	public List<OrderDetailResponseDTO> getHistory(@RequestParam Integer userId);

	@GetMapping("/Orders")
	public float placeOrder(@RequestParam Integer userId);
}

package com.account.java.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.account.java.dto.OrderDetailRequestDTO;
import com.account.java.dto.OrderDetailResponseDTO;
import com.account.java.feign.OrderServiceClient;
import com.account.java.service.AccountService;


@RestController
public class AccountController {

	@Autowired
	AccountService service;
	//@Autowired
	//OrderServiceClient orderClient;
	
	@GetMapping("/balance/{userId}")
	public float getBalance(@PathVariable Integer userId) {
		float balance=service.getbalance(userId);
		return balance;
	}
	/*@GetMapping("/feign/OrderHistory/{userId}")
	public List<OrderDetailResponseDTO> getHistory(@PathVariable Integer userId){
		return orderClient.getHistory(userId);
	}*/
	
	@PostMapping("/transaction")
	public String performTransaction(@RequestBody OrderDetailRequestDTO dto) {
		String msg=service.transaction(dto);
		return msg;
	}
}
